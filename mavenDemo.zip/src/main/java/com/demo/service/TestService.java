package com.demo.service;

import com.demo.entity.Test;

public interface TestService {
	public Test qureyById(Integer Id);
}
